/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import Services from './components/Services';
import About from './components/About';
import HowIWork from './components/HowIWork';
import ContactFooter from './components/ContactFooter';
import FloatingWhatsApp from './components/FloatingWhatsApp';

export default function App() {
  return (
    <div id="portfolio-root" className="min-h-screen bg-[#14171c] text-[#ece7dd] font-sans selection:bg-[#c1583a] selection:text-[#ece7dd]">
      {/* Sticky Navigation */}
      <Navigation />

      {/* Main Editorial Content */}
      <main id="main-content">
        {/* Hero Section */}
        <Hero />

        {/* Services Section */}
        <Services />

        {/* About Section */}
        <About />

        {/* How I Work Section */}
        <HowIWork />
      </main>

      {/* Contact and Colophon / Footer */}
      <ContactFooter />

      {/* Floating Circular WhatsApp Button */}
      <FloatingWhatsApp />
    </div>
  );
}

