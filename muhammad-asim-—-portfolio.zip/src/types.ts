export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  description: string;
  disciplineHighlight?: string;
  deliverables?: string[];
}

export interface StatItem {
  number: string;
  label: string;
  description: string;
}
