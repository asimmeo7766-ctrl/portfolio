import React, { useState } from 'react';
import { Mail, MessageSquare, ArrowUpRight, Copy, Check } from 'lucide-react';

export default function ContactFooter() {
  const [copiedEmail, setCopiedEmail] = useState(false);

  const copyEmail = () => {
    navigator.clipboard.writeText('asimmeo7766@gmail.com');
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  return (
    <footer
      id="contact"
      aria-label="Contact and Colophon"
      className="pt-20 pb-16 sm:pt-28 sm:pb-24 bg-[#14171c]"
    >
      <div className="max-w-5xl mx-auto px-6 sm:px-8">
        {/* Contact Heading Section */}
        <div className="pb-12 border-b border-[#ece7dd]/10">
          <span className="text-xs uppercase font-mono tracking-widest text-[#b8934a] block mb-4">
            Section 04 / Inquiries &amp; Commissions
          </span>
          <h2
            id="contact-heading"
            className="text-3xl sm:text-5xl md:text-6xl font-serif text-[#ece7dd] font-normal tracking-tight leading-[1.1] max-w-3xl mb-8"
          >
            Have an upcoming deadline or complex brief? Let&apos;s discuss your project.
          </h2>
          <p className="text-base sm:text-lg text-[#aba59a] max-w-2xl leading-relaxed mb-10">
            Direct communication ensures immediate clarity on assignment requirements, referencing standards, and delivery schedules. Inquire through WhatsApp for rapid turnaround or email for comprehensive briefs.
          </p>

          {/* Primary Contact Channels */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
            {/* WhatsApp Contact Repeated */}
            <div id="contact-whatsapp-channel" className="border-t border-[#ece7dd]/15 pt-6 space-y-3">
              <span className="text-xs font-mono uppercase tracking-widest text-[#aba59a] block">
                Primary Channel / Instant Messenger
              </span>
              <div className="flex flex-col space-y-2">
                <a
                  id="contact-whatsapp-link"
                  href="https://wa.me/923229292184"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="editorial-link inline-flex items-center text-xl sm:text-2xl font-serif text-[#ece7dd] hover:text-[#b8934a]"
                >
                  <MessageSquare size={20} className="text-[#c1583a] mr-3 shrink-0" />
                  <span>+92 322 9292184</span>
                  <ArrowUpRight size={18} className="ml-2 text-[#b8934a]" />
                </a>
                <p className="text-xs text-[#aba59a] font-sans">
                  Quickest response for quotes, urgent deadlines, and immediate consultations.
                </p>
              </div>
            </div>

            {/* Email Link */}
            <div id="contact-email-channel" className="border-t border-[#ece7dd]/15 pt-6 space-y-3">
              <span className="text-xs font-mono uppercase tracking-widest text-[#aba59a] block">
                Formal Correspondence / Document Briefs
              </span>
              <div className="flex flex-col space-y-2">
                <div className="flex items-center space-x-3">
                  <a
                    id="contact-email-link"
                    href="mailto:asimmeo7766@gmail.com"
                    className="editorial-link inline-flex items-center text-xl sm:text-2xl font-serif text-[#ece7dd] hover:text-[#b8934a]"
                  >
                    <Mail size={20} className="text-[#b8934a] mr-3 shrink-0" />
                    <span>asimmeo7766@gmail.com</span>
                    <ArrowUpRight size={18} className="ml-2 text-[#b8934a]" />
                  </a>
                  <button
                    onClick={copyEmail}
                    title="Copy email to clipboard"
                    className="p-1.5 text-[#aba59a] hover:text-[#ece7dd] transition-colors"
                    aria-label="Copy email address"
                  >
                    {copiedEmail ? <Check size={16} className="text-emerald-400" /> : <Copy size={16} />}
                  </button>
                </div>
                <p className="text-xs text-[#aba59a] font-sans">
                  Best suited for sending large files, rubrics, drafts, and guideline attachments.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Editorial Colophon / Footer Bottom */}
        <div className="pt-12 flex flex-col sm:flex-row sm:items-center justify-between gap-6 text-xs text-[#aba59a] font-mono">
          <div className="space-y-1">
            <p className="text-[#ece7dd]">
              Muhammad Asim &mdash; Independent Writing &amp; Editorial Practice
            </p>
            <p className="text-[#aba59a]/70">
              Set in Fraunces and Inter &middot; 100% Original Content Guarantee
            </p>
          </div>

          <div className="flex items-center space-x-6">
            <a
              href="#services"
              className="editorial-link hover:text-[#ece7dd]"
            >
              Services
            </a>
            <a
              href="#about"
              className="editorial-link hover:text-[#ece7dd]"
            >
              About
            </a>
            <a
              href="#contact"
              className="editorial-link hover:text-[#ece7dd]"
            >
              Contact
            </a>
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="editorial-link text-[#b8934a] hover:text-[#ece7dd]"
            >
              Back to Top &uarr;
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
