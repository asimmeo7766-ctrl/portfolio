import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';

export default function Navigation() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const scrollTo = (id: string) => {
    setIsMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const navOffset = 70;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - navOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <header
      id="site-navigation"
      className="sticky top-0 z-40 w-full bg-[#14171c]/92 backdrop-blur-md border-b border-[#ece7dd]/10 transition-colors duration-300"
    >
      <div className="max-w-5xl mx-auto px-6 sm:px-8 h-18 flex items-center justify-between">
        {/* Brand / Name */}
        <div className="flex items-baseline space-x-3">
          <a
            id="nav-brand-link"
            href="#"
            onClick={(e) => {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="text-lg sm:text-xl font-serif tracking-tight text-[#ece7dd] hover:text-[#b8934a] transition-colors"
          >
            Muhammad Asim
          </a>
          <span className="hidden sm:inline-block text-xs uppercase tracking-widest text-[#aba59a] font-mono">
            / Editorial Practice
          </span>
        </div>

        {/* Desktop Navigation Links */}
        <nav id="desktop-nav" aria-label="Main Navigation" className="hidden md:flex items-center space-x-8">
          <button
            id="nav-services-link"
            onClick={() => scrollTo('services')}
            className="editorial-link text-sm font-medium text-[#ece7dd]/80 hover:text-[#ece7dd] cursor-pointer"
          >
            Services
          </button>
          <button
            id="nav-about-link"
            onClick={() => scrollTo('about')}
            className="editorial-link text-sm font-medium text-[#ece7dd]/80 hover:text-[#ece7dd] cursor-pointer"
          >
            About
          </button>
          <button
            id="nav-contact-link"
            onClick={() => scrollTo('contact')}
            className="editorial-link text-sm font-medium text-[#ece7dd]/80 hover:text-[#ece7dd] cursor-pointer"
          >
            Contact
          </button>
          <a
            id="nav-whatsapp-cta"
            href="https://wa.me/923229292184"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs uppercase tracking-wider font-mono text-[#b8934a] hover:text-[#ece7dd] border border-[#b8934a]/30 hover:border-[#b8934a] px-3.5 py-1.5 transition-colors duration-200"
          >
            Available Now
          </a>
        </nav>

        {/* Mobile menu toggle */}
        <div className="md:hidden flex items-center">
          <button
            id="mobile-menu-toggle-button"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 text-[#ece7dd] hover:text-[#b8934a] focus:outline-none"
            aria-label="Toggle navigation menu"
            aria-expanded={isMobileMenuOpen}
          >
            {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile dropdown */}
      {isMobileMenuOpen && (
        <div
          id="mobile-nav-menu"
          className="md:hidden border-b border-[#ece7dd]/10 bg-[#14171c] px-6 py-6 space-y-4"
        >
          <div className="flex flex-col space-y-4">
            <button
              id="mobile-services-link"
              onClick={() => scrollTo('services')}
              className="text-left text-base font-serif text-[#ece7dd] hover:text-[#b8934a] py-1 border-b border-[#ece7dd]/5"
            >
              01. Services
            </button>
            <button
              id="mobile-about-link"
              onClick={() => scrollTo('about')}
              className="text-left text-base font-serif text-[#ece7dd] hover:text-[#b8934a] py-1 border-b border-[#ece7dd]/5"
            >
              02. About
            </button>
            <button
              id="mobile-contact-link"
              onClick={() => scrollTo('contact')}
              className="text-left text-base font-serif text-[#ece7dd] hover:text-[#b8934a] py-1 border-b border-[#ece7dd]/5"
            >
              03. Contact
            </button>
          </div>
          <div className="pt-2">
            <a
              id="mobile-whatsapp-cta"
              href="https://wa.me/923229292184"
              target="_blank"
              rel="noopener noreferrer"
              className="block text-center text-xs uppercase tracking-wider font-mono bg-[#c1583a] text-[#ece7dd] py-3 px-4 hover:bg-[#d26546] transition-colors"
            >
              Chat on WhatsApp
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
