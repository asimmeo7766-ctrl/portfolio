import React from 'react';
import { StatItem } from '../types';

const statsData: StatItem[] = [
  {
    number: '24–48h',
    label: 'Turnaround Time',
    description: 'Rapid, dependable completion calibrated to urgent submission deadlines without sacrificing analytical rigor.'
  },
  {
    number: '100%',
    label: 'Originality Guarantee',
    description: 'Completely bespoke human writing. Every manuscript is certified plagiarism-free with zero algorithmic flags.'
  },
  {
    number: 'Complimentary',
    label: 'Free Revisions',
    description: 'Comprehensive post-delivery modifications until your brief, grading rubric, and supervisor remarks are satisfied in full.'
  }
];

export default function HowIWork() {
  return (
    <section
      id="how-i-work"
      aria-label="How I Work"
      className="py-20 sm:py-28 border-b border-[#ece7dd]/10"
    >
      <div className="max-w-5xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="pb-6 border-b border-[#ece7dd]/10 mb-14 sm:mb-20">
          <span className="text-xs uppercase font-mono tracking-widest text-[#b8934a] block mb-3">
            Section 03 / Operational Standards
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-[#ece7dd] tracking-tight font-normal">
            How I Work
          </h2>
        </div>

        {/* Three quick stats with editorial presentation (hairline dividers, generous whitespace, no card grids/shadows) */}
        <div
          id="stats-container"
          className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-[#ece7dd]/12"
        >
          {statsData.map((stat, index) => (
            <div
              key={index}
              id={`stat-block-${index + 1}`}
              className="py-8 md:py-0 md:px-8 first:md:pl-0 last:md:pr-0 space-y-4"
            >
              <div className="space-y-1">
                <span className="text-xs font-mono uppercase tracking-widest text-[#aba59a] block">
                  Metric {String(index + 1).padStart(2, '0')}
                </span>
                <p className="text-3xl sm:text-4xl font-serif text-[#ece7dd] tracking-tight font-normal">
                  {stat.number}
                </p>
              </div>

              <h3 className="text-lg font-serif text-[#b8934a] font-normal tracking-tight">
                {stat.label}
              </h3>

              <p className="text-sm text-[#ece7dd]/80 leading-relaxed font-normal">
                {stat.description}
              </p>
            </div>
          ))}
        </div>

        {/* Editorial process flow summary */}
        <div className="mt-16 pt-10 border-t border-[#ece7dd]/10">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-baseline">
            <div className="md:col-span-3">
              <span className="text-xs uppercase font-mono tracking-widest text-[#c1583a] block">
                The Engagement Protocol
              </span>
            </div>
            <div className="md:col-span-9">
              <ol className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs text-[#aba59a] font-mono">
                <li className="space-y-1.5">
                  <span className="text-[#ece7dd] block font-medium">1. Brief Submission</span>
                  <span>Send your assignment prompt, rubric, word count, and reference style over WhatsApp or email.</span>
                </li>
                <li className="space-y-1.5">
                  <span className="text-[#ece7dd] block font-medium">2. Drafting &amp; Auditing</span>
                  <span>Researched and drafted line by line, followed by originality and AI-detection screening.</span>
                </li>
                <li className="space-y-1.5">
                  <span className="text-[#ece7dd] block font-medium">3. Final Delivery</span>
                  <span>Receive the polished document, reference citations, and free subsequent refinement.</span>
                </li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
