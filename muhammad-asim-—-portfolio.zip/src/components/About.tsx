import React from 'react';
import { Feather, BookOpen, CheckCircle } from 'lucide-react';

export default function About() {
  return (
    <section
      id="about"
      aria-label="About Muhammad Asim"
      className="py-20 sm:py-28 border-b border-[#ece7dd]/10"
    >
      <div className="max-w-5xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="pb-6 border-b border-[#ece7dd]/10 mb-14 sm:mb-20">
          <span className="text-xs uppercase font-mono tracking-widest text-[#b8934a] block mb-3">
            Section 02 / Biography &amp; Practice
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-[#ece7dd] tracking-tight font-normal">
            About the Practice
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 sm:gap-16 items-start">
          {/* Editorial Placeholder Portrait Block */}
          <div className="md:col-span-5 order-2 md:order-1">
            <figure id="portrait-placeholder-block" className="space-y-3">
              {/* Outer frame with hairline border, no drop shadow */}
              <div className="relative aspect-[4/5] bg-[#1a1e26] border border-[#ece7dd]/20 flex flex-col items-center justify-between p-8 sm:p-10 overflow-hidden">
                {/* Corner registration marks typical of editorial proof plates */}
                <span className="absolute top-2 left-2 text-[10px] font-mono text-[#aba59a]/50 select-none">+</span>
                <span className="absolute top-2 right-2 text-[10px] font-mono text-[#aba59a]/50 select-none">+</span>
                <span className="absolute bottom-2 left-2 text-[10px] font-mono text-[#aba59a]/50 select-none">+</span>
                <span className="absolute bottom-2 right-2 text-[10px] font-mono text-[#aba59a]/50 select-none">+</span>

                {/* Top plate marker */}
                <div className="w-full flex justify-between items-center text-[10px] font-mono uppercase tracking-widest text-[#aba59a]">
                  <span>Plate No. 01</span>
                  <span className="text-[#b8934a]">Author Portrait</span>
                </div>

                {/* Central Editorial Monogram & Literary Motif */}
                <div className="my-auto flex flex-col items-center text-center space-y-4">
                  <div className="w-24 h-24 rounded-full border border-[#b8934a]/40 bg-[#14171c] flex items-center justify-center">
                    <span className="font-serif text-3xl sm:text-4xl text-[#ece7dd] font-light tracking-normal">
                      MA
                    </span>
                  </div>
                  <div className="space-y-1">
                    <p className="font-serif italic text-sm text-[#ece7dd]/90">
                      Muhammad Asim
                    </p>
                    <p className="text-[11px] font-mono text-[#aba59a] uppercase tracking-wider">
                      Writer &middot; Editor &middot; Stylist
                    </p>
                  </div>
                </div>

                {/* Bottom plate spec */}
                <div className="w-full pt-4 border-t border-[#ece7dd]/10 text-center text-[10px] font-mono text-[#aba59a] tracking-wider uppercase">
                  <span>Independent Practitioner</span>
                </div>
              </div>

              {/* Caption underneath portrait */}
              <figcaption className="text-xs font-mono text-[#aba59a] leading-relaxed pt-1">
                Fig. 1 &mdash; Muhammad Asim operates an independent writing and editorial studio delivering custom academic solutions globally.
              </figcaption>
            </figure>
          </div>

          {/* Bio Text Column */}
          <div className="md:col-span-7 order-1 md:order-2 space-y-6">
            <h3 className="text-2xl sm:text-3xl font-serif text-[#ece7dd] font-normal leading-snug">
              Writing crafted with academic rigor, intellectual honesty, and an editorial eye for rhythm.
            </h3>

            {/* Short bio paragraph as requested */}
            <p className="text-base sm:text-lg text-[#ece7dd]/85 leading-relaxed font-normal">
              I am Muhammad Asim, a dedicated freelance writing professional and editorial specialist. Over years of hands-on practice, I have partnered with students, researchers, and busy professionals who require dependable, publication-standard written work. My practice is built upon three non-negotiable foundations: absolute originality with zero plagiarism, nuanced human phrasing that decisively overcomes the monotony of AI models, and meticulous structural formatting aligned to international academic standards.
            </p>

            <p className="text-sm sm:text-base text-[#aba59a] leading-relaxed">
              In an era where algorithmic generation creates repetitive, lifeless drafts, I specialize in injecting genuine scholarly depth and natural linguistic rhythm back into manuscripts. Every brief entrusted to me receives thorough individualized research, adherence to your institution's specific referencing manual, and unlimited post-delivery refinement until your goals are met.
            </p>

            {/* Editorial highlights / credentials list */}
            <div className="pt-6 border-t border-[#ece7dd]/10 space-y-4">
              <div className="flex items-start space-x-3 text-sm text-[#ece7dd]/90">
                <Feather size={16} className="text-[#c1583a] mt-1 shrink-0" />
                <span>
                  <strong className="text-[#ece7dd] font-medium">Bespoke Research:</strong> Every paper is developed from primary scholarly databases, peer-reviewed journals, and customized source materials.
                </span>
              </div>
              <div className="flex items-start space-x-3 text-sm text-[#ece7dd]/90">
                <BookOpen size={16} className="text-[#b8934a] mt-1 shrink-0" />
                <span>
                  <strong className="text-[#ece7dd] font-medium">Academic Standards:</strong> Expert command over APA, Harvard, MLA, Chicago, and IEEE citation styles, ensuring zero formatting deductions.
                </span>
              </div>
              <div className="flex items-start space-x-3 text-sm text-[#ece7dd]/90">
                <CheckCircle size={16} className="text-[#c1583a] mt-1 shrink-0" />
                <span>
                  <strong className="text-[#ece7dd] font-medium">Verified Compliance:</strong> All writing is cross-verified with institutional plagiarism and AI-detection tools before release.
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
