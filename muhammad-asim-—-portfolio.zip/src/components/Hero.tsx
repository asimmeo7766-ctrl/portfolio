import React from 'react';
import { motion } from 'motion/react';
import { ArrowDownRight, MessageSquare } from 'lucide-react';

export default function Hero() {
  const scrollToServices = (e: React.MouseEvent) => {
    e.preventDefault();
    const element = document.getElementById('services');
    if (element) {
      const navOffset = 70;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - navOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section
      id="hero"
      aria-label="Introduction"
      className="relative pt-20 pb-20 sm:pt-28 sm:pb-28 border-b border-[#ece7dd]/10"
    >
      <div className="max-w-5xl mx-auto px-6 sm:px-8">
        {/* Subtle issue/edition date indicator in editorial style */}
        <div className="flex items-center justify-between text-xs font-mono tracking-widest text-[#aba59a] uppercase pb-8 border-b border-[#ece7dd]/10 mb-12">
          <span>Freelance Writing & Editorial</span>
          <span className="text-[#b8934a]">Available for New Commissions</span>
        </div>

        <div className="max-w-3xl">
          {/* Hero Name with the single allowed entrance animation */}
          <motion.h1
            id="hero-author-name"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="text-4xl sm:text-6xl md:text-7xl font-serif font-normal tracking-tight text-[#ece7dd] leading-[1.08] mb-6"
          >
            Muhammad Asim
          </motion.h1>

          {/* One-line tagline about the three services */}
          <p
            id="hero-tagline"
            className="text-lg sm:text-xl font-serif italic text-[#b8934a] leading-relaxed mb-6 font-light"
          >
            Custom academic assignment writing, nuanced AI-content humanizing, and thorough pre-submission report checking.
          </p>

          {/* Short standfirst paragraph */}
          <p
            id="hero-standfirst"
            className="text-base sm:text-lg text-[#ece7dd]/80 leading-relaxed font-normal max-w-2xl mb-10 text-pretty"
          >
            An independent editorial practice for scholars, professionals, and creators seeking immaculate prose. Every project is handled with rigorous academic integrity, nuanced human phrasing that effortlessly transcends algorithmic detection, and structural precision tailored to your specific submission standards.
          </p>

          {/* Call-to-action buttons */}
          <div id="hero-actions" className="flex flex-wrap items-center gap-4 sm:gap-6 pt-2">
            {/* Primary button: Chat on WhatsApp */}
            <a
              id="hero-primary-whatsapp-button"
              href="https://wa.me/923229292184"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-2.5 bg-[#c1583a] hover:bg-[#d26546] text-[#ece7dd] text-sm font-medium px-6 py-3.5 transition-colors duration-200"
            >
              <MessageSquare size={16} className="text-[#ece7dd]" />
              <span>Chat on WhatsApp</span>
            </a>

            {/* Secondary button: See services */}
            <a
              id="hero-secondary-services-button"
              href="#services"
              onClick={scrollToServices}
              className="inline-flex items-center space-x-2 text-sm font-medium text-[#ece7dd] hover:text-[#b8934a] border border-[#ece7dd]/20 hover:border-[#b8934a]/60 px-6 py-3.5 transition-colors duration-200"
            >
              <span>See services</span>
              <ArrowDownRight size={16} className="text-[#b8934a]" />
            </a>
          </div>
        </div>

        {/* Editorial Footnote detail */}
        <div className="mt-16 pt-6 border-t border-[#ece7dd]/10 flex flex-col sm:flex-row sm:items-center justify-between text-xs text-[#aba59a] font-mono gap-2">
          <span>Based in Pakistan &middot; Serving Clients Globally</span>
          <span>Response Window: Typically &lt; 2 Hours</span>
        </div>
      </div>
    </section>
  );
}
