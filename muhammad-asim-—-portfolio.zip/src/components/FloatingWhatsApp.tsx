import React, { useState } from 'react';

export default function FloatingWhatsApp() {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div className="fixed bottom-6 right-6 sm:bottom-8 sm:right-8 z-50 flex items-center">
      {/* Optional subtle hover pill label */}
      <span
        className={`hidden sm:inline-block mr-3 px-3 py-1.5 bg-[#1b1f26] border border-[#ece7dd]/20 text-xs font-mono text-[#ece7dd] transition-opacity duration-200 pointer-events-none select-none ${
          isHovered ? 'opacity-100' : 'opacity-0'
        }`}
      >
        Chat on WhatsApp
      </span>

      {/* Floating circular WhatsApp button with subtle pulse animation */}
      <a
        id="floating-whatsapp-button"
        href="https://wa.me/923229292184"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat with Muhammad Asim on WhatsApp"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        className="subtle-pulse-button relative flex items-center justify-center w-14 h-14 rounded-full bg-[#c1583a] hover:bg-[#d26546] text-[#ece7dd] border border-[#ece7dd]/20 transition-transform duration-200 active:scale-95 focus:outline-none focus:ring-2 focus:ring-[#b8934a]"
      >
        {/* Clean WhatsApp SVG icon */}
        <svg
          className="w-7 h-7 fill-current"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
          aria-hidden="true"
        >
          <path d="M17.472 14.382c-.301-.15-1.781-.879-2.057-.979-.276-.1-.476-.15-.676.15-.2.301-.776.979-.951 1.18-.175.201-.351.226-.652.075-.301-.15-1.27-.468-2.42-1.493-.894-.798-1.498-1.784-1.674-2.085-.175-.301-.019-.464.132-.614.136-.135.301-.351.451-.527.15-.175.201-.301.301-.501.1-.2.05-.376-.025-.526-.075-.15-.676-1.63-1.026-2.433-.251-.602-.501-.526-.676-.526h-.576c-.2 0-.526.075-.802.376-.276.301-1.052 1.028-1.052 2.507s1.077 2.908 1.228 3.109c.15.201 2.119 3.236 5.134 4.54.718.31 1.278.496 1.715.635.72.229 1.376.197 1.895.12.578-.087 1.781-.727 2.032-1.429.25-.702.25-1.303.175-1.429-.075-.125-.276-.2-.577-.35zM12.04 2C6.51 2 2.025 6.485 2.025 12.015c0 1.83.493 3.548 1.353 5.035L2 22l5.127-1.344c1.432.782 3.072 1.233 4.913 1.233 5.53 0 10.015-4.485 10.015-10.015S17.57 2 12.04 2zm0 18.257c-1.63 0-3.136-.445-4.432-1.22l-.317-.19-3.298.865.88-3.216-.208-.331a8.163 8.163 0 0 1-1.253-4.38c0-4.526 3.682-8.208 8.21-8.208 4.528 0 8.21 3.682 8.21 8.208 0 4.526-3.682 8.272-8.21 8.272z" />
        </svg>
      </a>
    </div>
  );
}
