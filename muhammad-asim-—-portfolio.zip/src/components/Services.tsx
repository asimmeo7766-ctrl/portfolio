import React from 'react';
import { ArrowUpRight } from 'lucide-react';
import { ServiceItem } from '../types';

const servicesData: ServiceItem[] = [
  {
    id: 'assignment-writing',
    number: '01',
    title: 'Assignment Writing',
    description: "Custom academic assignments written to a client's brief, referencing style, and deadline, 100% original and plagiarism-free.",
    disciplineHighlight: 'APA 7th, Harvard, Chicago, IEEE, MLA & OSCOLA standards accommodated',
    deliverables: [
      'Comprehensive primary & peer-reviewed research',
      'Original Turnitin similarity verification report',
      'Direct alignment with module rubrics & marking criteria'
    ]
  },
  {
    id: 'content-humanizing',
    number: '02',
    title: 'Content Humanizing',
    description: 'Rewriting AI-generated text into natural, human-sounding writing that passes AI-detection checks.',
    disciplineHighlight: 'Tested against Turnitin AI, GPTZero, Originality.ai & Copyleaks',
    deliverables: [
      'Removal of algorithmic cadence, repetitive syntax, and AI clichés',
      'Infusion of natural stylistic rhythm, authentic voice, and varied syntax',
      'Preservation of core subject arguments and domain-specific terminology'
    ]
  },
  {
    id: 'report-checking',
    number: '03',
    title: 'Report Checking',
    description: 'Proofreading, formatting, and structural review of reports before submission.',
    disciplineHighlight: 'Academic dissertations, corporate reports, executive briefings & proposals',
    deliverables: [
      'Rigorous line-by-line syntax, grammatical, and typographical proofing',
      'Typography, margins, tables, and bibliography layout standardization',
      'Logical flow enhancement and executive summary coherence'
    ]
  }
];

export default function Services() {
  return (
    <section
      id="services"
      aria-label="Services"
      className="py-20 sm:py-28 border-b border-[#ece7dd]/10"
    >
      <div className="max-w-5xl mx-auto px-6 sm:px-8">
        {/* Editorial Section Header */}
        <div className="mb-14 sm:mb-20 flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-[#ece7dd]/10">
          <div>
            <span className="text-xs uppercase font-mono tracking-widest text-[#b8934a] block mb-3">
              Section 01 / Catalogue
            </span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif text-[#ece7dd] tracking-tight font-normal">
              Services &amp; Offerings
            </h2>
          </div>
          <p className="text-sm text-[#aba59a] max-w-sm font-sans leading-relaxed">
            Tailored editorial support designed to satisfy rigorous academic standards and deliver authentic human prose.
          </p>
        </div>

        {/* Numbered Editorial Index List (no card grids, no drop shadows) */}
        <div id="services-index-list" className="divide-y divide-[#ece7dd]/12">
          {servicesData.map((service) => (
            <article
              key={service.id}
              id={`service-item-${service.number}`}
              className="py-12 sm:py-16 first:pt-4 last:pb-8 group"
            >
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 sm:gap-8 items-start">
                {/* Index Numeral */}
                <div className="md:col-span-2">
                  <span className="text-2xl sm:text-3xl font-mono text-[#b8934a] tracking-wider block">
                    {service.number}
                  </span>
                  <span className="text-[11px] uppercase tracking-widest text-[#aba59a] font-mono mt-1 block">
                    Offering
                  </span>
                </div>

                {/* Title & Core Description */}
                <div className="md:col-span-6 space-y-4">
                  <h3 className="text-2xl sm:text-3xl font-serif text-[#ece7dd] tracking-tight group-hover:text-[#b8934a] transition-colors duration-200">
                    {service.title}
                  </h3>
                  <p className="text-base sm:text-lg text-[#ece7dd]/90 leading-relaxed font-normal">
                    {service.description}
                  </p>
                  {service.disciplineHighlight && (
                    <p className="text-xs font-mono uppercase tracking-wider text-[#aba59a] pt-1">
                      <span className="text-[#c1583a] mr-1.5">&sect;</span>
                      {service.disciplineHighlight}
                    </p>
                  )}
                </div>

                {/* Key Deliverables & Direct Action */}
                <div className="md:col-span-4 flex flex-col justify-between h-full pt-1 md:pt-0">
                  {service.deliverables && (
                    <ul className="space-y-2 mb-6 text-xs text-[#aba59a] font-sans">
                      {service.deliverables.map((item, idx) => (
                        <li key={idx} className="flex items-start">
                          <span className="text-[#b8934a] mr-2 select-none">&mdash;</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  )}

                  <div className="pt-2">
                    <a
                      id={`service-inquiry-${service.number}`}
                      href={`https://wa.me/923229292184?text=${encodeURIComponent(
                        `Hello Muhammad, I am interested in your ${service.title} service. Could we discuss availability and details?`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="editorial-link inline-flex items-center text-xs font-mono tracking-wider uppercase text-[#c1583a] hover:text-[#ece7dd]"
                    >
                      <span>Commission this service</span>
                      <ArrowUpRight size={14} className="ml-1" />
                    </a>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
